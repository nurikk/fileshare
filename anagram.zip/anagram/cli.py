import argparse
import sys

from anagram.process import process_file


def parse_arguments(argv):
    parser = argparse.ArgumentParser(description='Find anagrams in a given file')
    parser.add_argument('file_path', type=argparse.FileType('r', encoding='UTF-8'), help='File to process')
    return parser.parse_args(argv)


if __name__ == "__main__":
    args = parse_arguments(sys.argv[1:])

    for anagrams in process_file(args.file_path):
        for anagram_matches in anagrams:
            print(','.join(anagram_matches))
