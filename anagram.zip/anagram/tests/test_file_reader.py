import os

import pytest

from anagram.process import read_word_groups_from_file

FIXTURE_DIR = os.path.join(
    os.path.dirname(os.path.realpath(__file__)),
    'data'
)


@pytest.mark.parametrize('input_file, expected_expected', [
    (open(os.path.join(FIXTURE_DIR, 'file1.txt')), [
        ['fff', 'fff', 'asd'], ['ab'], ['aa', 'aa']
    ]),
    (open(os.path.join(FIXTURE_DIR, 'dummy.txt')), [['hello, I\'m dummy file']]),
])
def test_read_work_groups_from_file(input_file, expected_expected):
    res = read_word_groups_from_file(input_file)
    assert sorted(list(res)) == sorted(expected_expected)
