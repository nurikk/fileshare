import timeit

import pytest
from prettytable import PrettyTable

from anagram.input_validators import AnagramSet, AnagramSort, AnagramCounter

test_anagrams_params = [
    (
        "abc", "cab", True
    ),
    (
        "abc", "cabaa", False
    ),
    (
        "", "cab", False
    ),
    (
        "", "", False
    ),
    (
        None, None, False
    ),
    (
        1, 123, False
    ),
    (
        1, "123", False
    ),
    (
        1, False, False
    )
]


@pytest.mark.parametrize('str1, str2, is_anagram', test_anagrams_params)
def test_anagram(str1, str2, is_anagram):
    set_anagram = AnagramSet()
    sort_anagram = AnagramSort()
    counter_anagram = AnagramCounter()

    assert set_anagram.is_anagram(str1, str2) == is_anagram
    assert sort_anagram.is_anagram(str1, str2) == is_anagram
    assert counter_anagram.is_anagram(str1, str2) == is_anagram


# |  sample  |   implementation   |   execution time   |
# +----------+--------------------+--------------------+
# |    1     |  is_anagram_sort   | 0.7106331669999999 |
# |    1     | is_anagram_counter | 1.7649974579999999 |
# |    1     |   is_anagram_set   | 0.7730949579999997 |
# |    -     |         -          |         -          |
# |    22    |  is_anagram_sort   | 0.7303504580000002 |
# |    22    | is_anagram_counter |    1.808245791     |
# |    22    |   is_anagram_set   | 0.8117352919999998 |
# |    -     |         -          |         -          |
# |   333    |  is_anagram_sort   | 0.7665037080000001 |
# |   333    | is_anagram_counter | 1.8933111249999994 |
# |   333    |   is_anagram_set   | 0.8215698749999998 |
# |    -     |         -          |         -          |
# |   4444   |  is_anagram_sort   |    0.797245084     |
# |   4444   | is_anagram_counter | 1.9585578329999986 |
# |   4444   |   is_anagram_set   | 0.8412322500000009 |
# |    -     |         -          |         -          |
# |  55555   |  is_anagram_sort   | 0.8047572089999999 |
# |  55555   | is_anagram_counter | 1.9888660839999996 |
# |  55555   |   is_anagram_set   | 0.8487049169999992 |
# |    -     |         -          |         -          |
# |  666666  |  is_anagram_sort   | 0.8484747500000012 |
# |  666666  | is_anagram_counter | 2.0311520419999987 |
# |  666666  |   is_anagram_set   | 0.8562841669999983 |
# |    -     |         -          |         -          |
# | 77777777 |  is_anagram_sort   | 0.4089770829999999 |
# | 77777777 | is_anagram_counter | 0.4093947920000005 |
# | 77777777 |   is_anagram_set   | 0.4163020419999981 |
# |    -     |         -          |         -          |
# +----------+--------------------+--------------------+
@pytest.mark.skip(reason="Disable benches")
def test_benchmark():
    set_anagram = AnagramSet()
    sort_anagram = AnagramSort()
    counter_anagram = AnagramCounter()

    test_cases = [
        ('1', '1'),
        ('22', '22'),
        ('333', '333'),
        ('4444', '4444'),
        ('55555', '55555'),
        ('666666', '666666'),
        ('77777777', '7777777'),
    ]
    x = PrettyTable(['sample', 'implementation', 'execution time'])
    for test_case in test_cases:
        x.add_row([
            test_case[0],
            "is_anagram_sort",
            timeit.timeit(lambda: sort_anagram.is_anagram(test_case[0], test_case[1]))
        ])

        x.add_row([
            test_case[0],
            "is_anagram_counter",
            timeit.timeit(lambda: counter_anagram.is_anagram(test_case[0], test_case[1]))
        ])

        x.add_row([
            test_case[0],
            "is_anagram_set",
            timeit.timeit(lambda: set_anagram.is_anagram(test_case[0], test_case[1]))
        ])
        x.add_row(['-', '-', '-'])
    print(x)


