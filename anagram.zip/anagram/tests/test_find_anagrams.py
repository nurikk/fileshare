import timeit

import pytest

from anagram.process import find_anagrams, find_anagrams_collections

test_params = [
    (['aa', 'bb', 'ab'], []),
    (['abc', 'cab', 'ab'], [['abc', 'cab']]),
    ([None, 'cab', 'acb', '', False, True], [['acb', 'cab']]),
]


@pytest.mark.parametrize('lines, expected', test_params)
def test_find_anagrams(lines, expected):
    assert expected == sorted(map(sorted, find_anagrams(lines)))
    assert expected == sorted(map(sorted, find_anagrams_collections(lines)))


@pytest.mark.skip(reason="Disable benches")
@pytest.mark.parametrize('lines, expected', test_params)
def test_bench_anagrams(lines, expected):
    t1 = timeit.timeit(lambda: find_anagrams(lines))
    t2 = timeit.timeit(lambda: find_anagrams_collections(lines))
    print(f't1 = {t1} t2 = {t2}')
