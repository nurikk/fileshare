import os
from argparse import Namespace

import pytest

from cli import parse_arguments
from tests.test_file_reader import FIXTURE_DIR


def test_parse_non_existing_file_args():
    with pytest.raises(SystemExit):
        parse_arguments(['non existing file'])


@pytest.mark.parametrize('args, expected', [
    (['/etc/hosts'], Namespace(file_path=open('/etc/hosts'))),
    ([os.path.join(FIXTURE_DIR, 'dummy.txt')], Namespace(file_path=open(os.path.join(FIXTURE_DIR, 'dummy.txt')))),
    ([os.path.join(FIXTURE_DIR, './dummy.txt')], Namespace(file_path=open(os.path.join(FIXTURE_DIR, './dummy.txt')))),
])
def test_parse_args(args, expected):
    assert parse_arguments(args).file_path.name == expected.file_path.name
