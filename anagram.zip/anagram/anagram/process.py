import itertools
from collections import defaultdict
from io import TextIOWrapper

from typing import List, Iterator

from anagram.input_validators import is_valid_string, AnagramSort


def has_more_than_one_anagram(group: List):
    return len(group) > 1


def find_anagrams(lines: List[str]) -> List[List[str]]:
    anagram = AnagramSort()

    groups = defaultdict(list)
    for line in filter(is_valid_string, lines):
        groups[anagram.to_normalised_string(line)].append(line)

    return list(filter(has_more_than_one_anagram, groups.values()))


def find_anagrams_collections(lines: List[str]) -> List[List[str]]:
    anagram = AnagramSort()

    results = []
    for key, grouper in itertools.groupby(sorted(filter(is_valid_string, lines)), anagram.to_normalised_string):
        group = list(grouper)
        if has_more_than_one_anagram(group):
            results.append(group)
    return results


def read_word_groups_from_file(file_path: TextIOWrapper) -> Iterator[List[str]]:
    tmp_buffer = []
    current_len = -1
    for current_line in file_path:
        stripped_current_line = current_line.strip()
        if is_valid_string(stripped_current_line):
            if len(current_line) != current_len:
                if len(tmp_buffer) > 0:
                    yield tmp_buffer
                current_len = len(current_line)
                tmp_buffer = []
            tmp_buffer.append(current_line.strip())
    if len(tmp_buffer) > 0:
        yield tmp_buffer


def process_file(file_path: TextIOWrapper) -> Iterator[List[str]]:
    for lines in read_word_groups_from_file(file_path):
        anagrams = find_anagrams_collections(lines)
        yield anagrams
