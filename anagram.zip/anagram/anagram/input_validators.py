from abc import ABC, abstractmethod
from collections import Counter


def is_valid_string(a: str) -> bool:
    return a is not None and (type(a) == str and len(a) > 0)


def sanity_checks(a: str, b: str) -> bool:
    if not is_valid_string(a) or not is_valid_string(b):
        return False

    if len(a) != len(b):
        return False

    return True


class Anagram(ABC):
    def is_anagram(self, a: str, b: str) -> bool:
        if sanity_checks(a, b):
            return self.normalise(a) == self.normalise(b)
        return False

    def to_normalised_string(self, a: str) -> str:
        return str(self.normalise(a))

    @abstractmethod
    def normalise(self, a: str) -> object:
        pass  # pragma: no cover


class AnagramSort(Anagram):
    def normalise(self, a: str) -> list:
        return sorted(a)


class AnagramCounter(Anagram):
    def normalise(self, a: str) -> Counter:
        return Counter(a)


class AnagramSet(Anagram):
    def normalise(self, a: str) -> set:
        return set(a.lower())
