# Awesome anagram challenge
## Tech
- Language: python3 (written and tested on 3.8.12), should be compatible with 3.5+ due to typing usage

## Assumptions made
- empty lines are skipped

## How to run code
- `make setup` // once
- `make run`

or

- `python cli.py data/example2.txt`

## Big O analysis

Algorithm is very simple, it uses that fact that anagram string always contains
same amount of characters. So we can apply normalisation function to 
every string and then group them on this normalised value.
Anagram normalisation can be done in different ways (set/sorting/counter), but [benchmarks](./tests/test_anagram.py) shows that 
one of the most efficient normalisations is simple sorting characters.
Simple representation of all logic
```python
from collections import defaultdict
groups = defaultdict(list)
for line in lines:
    groups[normalise(line)].append(line)
```
But for sake of performance it was decided to use `itertools.groupby` grouping implementation instead of implementing grouping in python, gives 10-15% [performance](./tests/test_anagram.py) boost due to leveraging native c code in underlying package
Simple for loop over every line gives us `O(n)` which is totally fine as long as individual group of words can fit into the memory.

Implementation uses dictionary of lists, because we need fast access by normalised key 
and mutable collection to store strings. 


## Future improvements
 - Parallel(multiprocessor) processing
 - Python (pypy) package
 - Further iterator implementation, to use less memory for file reading (possible?)


## How to run tests
 - `make setup-test` // once
 - `make test`

## Performance
To process example2.txt it takes `0.31s` on Apple M1 cpu, leveraging multiprocessor processing wil descrease this time
`python cli.py data/example2.txt  0.31s user 0.02s system 92% cpu 0.353 total`